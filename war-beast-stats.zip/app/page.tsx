"use client";
import React, { useEffect, useState } from "react";
import { loadSharedData, type HeroData } from "@/src/sharedData";

export default function Page() {
  const [data, setData] = useState<HeroData>({
    "Metallic Dragon": [],
    "Crimson Reaper": [],
    "Mega Gorilla": [],
    "Lunar Viper": [],
    "Sky Ripper": [],
    "Panda": [],
  });

  useEffect(() => {
    loadSharedData().then(setData).catch(console.error);
  }, []);

  return (
    <div style={{ padding: 16 }}>
      <h1>War Beast Stats</h1>
      <p>Shared rows loaded: {Object.values(data).reduce((n, r) => n + r.length, 0)}</p>
    </div>
  );
}