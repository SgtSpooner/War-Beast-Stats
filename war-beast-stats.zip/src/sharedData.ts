import Papa from "papaparse";

export type HeroName =
  | "Metallic Dragon"
  | "Crimson Reaper"
  | "Mega Gorilla"
  | "Lunar Viper"
  | "Sky Ripper"
  | "Panda";

export type Row = { Level: number; Stat: string; Value: number };
export type HeroData = Record<HeroName, Row[]>;

const FILES: Record<HeroName, string> = {
  "Metallic Dragon": "/data/metallic_dragon.csv",
  "Crimson Reaper": "/data/crimson_reaper.csv",
  "Mega Gorilla": "/data/mega_gorilla.csv",
  "Lunar Viper": "/data/lunar_viper.csv",
  "Sky Ripper": "/data/sky_ripper.csv",
  "Panda": "/data/panda.csv",
};

function parseCSV(text: string): Row[] {
  const { data } = Papa.parse(text.trim(), { header: true, skipEmptyLines: true });
  return (data as any[])
    .map((r) => {
      const get = (k: string) =>
        r[Object.keys(r).find((x) => x.toLowerCase().trim() === k)!];
      const val = String(get("value") ?? "").replace(/[^0-9+-.]/g, "");
      return {
        Level: Number(get("level")),
        Stat: String(get("stat") ?? "").trim(),
        Value: Number(val),
      };
    })
    .filter((r) => Number.isFinite(r.Level) && Number.isFinite(r.Value) && r.Stat);
}

export async function loadSharedData(): Promise<HeroData> {
  const entries = await Promise.all(
    (Object.entries(FILES) as [HeroName, string][])
      .map(async ([hero, path]) => {
        const res = await fetch(path, { cache: "force-cache" });
        const text = await res.text();
        return [hero, parseCSV(text)] as const;
      })
  );
  return Object.fromEntries(entries) as HeroData;
}